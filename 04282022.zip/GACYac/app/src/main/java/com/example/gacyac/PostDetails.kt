package com.example.gacyac

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.gacyac.databinding.ActivityPostDetailsBinding

class PostDetails : AppCompatActivity() {

    private lateinit var binding : ActivityPostDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostDetailsBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_post_details)
        setContentView(binding.root)

        val postID = intent.getIntExtra(POST_ID_EXTRA, -1)
        val post = postFromID(postID)
        if(post != null){
            binding.postTitle.text = post.title
            binding.postText.text = post.text
            binding.postCreator.text = post.username
            binding.tcPlaceholder.text = post.time.toString()
            binding.bpPlaceholder.text = post.bonuspoints.toString()
        }

    }

    private fun postFromID(postID: Int): Post? {
        for(post in postList){
            if(post.id == postID) {
                return post
            }
        }
        return null
    }
}