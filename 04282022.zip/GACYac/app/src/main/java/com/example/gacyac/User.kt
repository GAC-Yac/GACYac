package com.example.gacyac

import java.util.*

class User (
    var username: String ?= null,
    var bonuspoints: Int ?= null,
    var dateJoined: Date ?= null
)