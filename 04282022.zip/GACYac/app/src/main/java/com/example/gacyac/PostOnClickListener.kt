package com.example.gacyac

interface PostOnClickListener{
    fun onClick(post: Post){

    }
}